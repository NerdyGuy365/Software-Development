The client samples are designed to be used with the main identityserver4 repo:

https://github.com/IdentityServer/IdentityServer4
