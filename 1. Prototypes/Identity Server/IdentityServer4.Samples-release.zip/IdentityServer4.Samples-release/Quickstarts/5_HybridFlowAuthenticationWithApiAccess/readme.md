# Quickstart #5: OpenID Connect Hybrid Flow Authentication and API Access Tokens

This quickstart we combine what we learned in the previous quickstarts and we explored both API access and user authentication. 

## Tutorial

The tutorial that goes along with this sample can be found here [Switching to Hybrid Flow and adding API Access back](http://docs.identityserver.io/en/release/quickstarts/5_hybrid_and_api_access.html)
