# Quickstart #6: IdentityServer and ASP.NET Identity

This quickstart uses ASP.NET Identity for identity management.