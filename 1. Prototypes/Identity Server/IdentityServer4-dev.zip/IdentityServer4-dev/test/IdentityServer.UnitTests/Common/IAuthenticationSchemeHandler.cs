﻿namespace IdentityServer.UnitTests.Common
{
    internal interface IAuthenticationSchemeHandler
    {
    }
}