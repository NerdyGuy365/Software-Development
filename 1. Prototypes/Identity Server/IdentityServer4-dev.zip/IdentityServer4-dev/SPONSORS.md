# Sponsors

We thank those who [support](https://www.patreon.com/identityserver) IdentityServer!

## Corporate

### Gold

[Thinktecture AG](https://www.thinktecture.com)  
[Ritter Insurance Marketing](https://www.ritterim.com)

### Silver

Green Elephant IT Consulting ([@Schwamster](https://twitter.com/Schwamster))  
Jacobus Roos  
Tomer Dvir  
Steinar	Noem  
Effectory ([@effectory](https://twitter.com/effectory))  

## Individuals

Khalid Abuhakmeh ([@buhakmeh](https://twitter.com/buhakmeh))  
Rasika Weliwita ([@rasikaweliwita](https://twitter.com/rasikaweliwita))  
Arun David Shelly  
Reece Williams ([@AnEmptyReece](https://twitter.com/AnEmptyReece))  
Alexander Zeitler ([@alexzeitler_](https://twitter.com/alexzeitler_))  
Tobias Höft ([@tobiashoeft](https://twitter.com/tobiashoeft))  
Richard Simpson ([@RichardSimp](https://twitter.com/RichardSimp))  
Gusztav Varga ([@gusztavvargadr](https://twitter.com/gusztavvargadr))  
William Grow  
Espen Medbø ([@emedbo](https://twitter.com/emedbo))  
John Korsnes ([@johnkors](https://twitter.com/johnkors))  
James Roberts  
Chris Simmons ([@netchrisdotcom](https://twitter.com/netchrisdotcom))  
Shawn Wildermuth  
Thomas C  
黃嘉華  
David Christiansen ([@dotnetopenauth](https://twitter.com/dotnetopenauth))  
Christian Riedl  
Ben	Cull  
Johan Boström ([@zarx](https://twitter.com/zarx))  
Chris White  
Albert ([@DerAlbert](https://twitter.com/DerAlbert))  
Hugo Biarge ([@hbiarge](https://twitter.com/hbiarge))  
Jacob Johnson  
Ibrahim Šuta ([@ibrahimsuta](https://twitter.com/ibrahimsuta))  
Dave Noderer  ([@davenoderer](https://twitter.com/davenoderer))  
